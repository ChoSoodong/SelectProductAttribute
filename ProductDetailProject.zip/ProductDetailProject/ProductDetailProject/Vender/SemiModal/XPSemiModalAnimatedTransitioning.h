






#import <UIKit/UIKit.h>

@interface XPSemiModalAnimatedTransitioning : NSObject <UIViewControllerAnimatedTransitioning>

@property (nonatomic, assign, getter=isPresentation) BOOL presentation;

@end
