






#import <UIKit/UIKit.h>

@interface XPSemiModalTransitioningDelegate : NSObject <UIViewControllerTransitioningDelegate>

@end
