







#import <UIKit/UIKit.h>

@class XPSemiModalConfiguration;

@interface XPSemiModalPresentationController : UIPresentationController

@property (nonatomic, strong) XPSemiModalConfiguration *configuration;

@end
