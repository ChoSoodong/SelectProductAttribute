






#import <UIKit/UIKit.h>

@interface SDChooseAttributePropertyHeader : UICollectionReusableView
/**     */
@property (strong, nonatomic) UILabel *headernameL;
@end
