







#import "SDChooseAttributePropertyCell.h"
#import "SDPropertyModel.h"

@interface SDChooseAttributePropertyCell()

/** 标签按钮 */
@property (nonatomic, strong) UIButton *textBtn;

@end

@implementation SDChooseAttributePropertyCell

- (instancetype)initWithFrame:(CGRect)frame {
    if (self) {
        self = [super initWithFrame:frame];
        self.contentView.backgroundColor = [UIColor whiteColor];
       
        
        _textBtn = [[UIButton alloc] init];
        _textBtn.layer.cornerRadius = 5;
        _textBtn.layer.masksToBounds = YES;
        _textBtn.backgroundColor = [UIColor groupTableViewBackgroundColor];
        _textBtn.titleLabel.font = [UIFont systemFontOfSize:14];
        [_textBtn setTitle:@"属性" forState:UIControlStateNormal];
        [_textBtn setTitle:@"属性" forState:UIControlStateSelected];
        [_textBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_textBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
        [_textBtn addTarget:self action:@selector(textBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:_textBtn];
    }
    return self;
}

-(void)layoutSubviews{
    [super layoutSubviews];

    _textBtn.frame = self.contentView.bounds;
}


-(void)textBtnClick:(UIButton *)sender{
    sender.selected = !sender.selected;
    
    self.propertyModel.isSelected = sender.isSelected;
    
    if (sender.selected) {
        self.textBtn.backgroundColor = [UIColor redColor];
    
    }else{
        self.textBtn.backgroundColor = [UIColor groupTableViewBackgroundColor];
    }
    
    //回调
    if (self.CellButtonBlock) {
        self.CellButtonBlock(self.propertyModel);
    }
}


-(void)setPropertyModel:(SDPropertyModel *)propertyModel{
    _propertyModel = propertyModel;
    
    [_textBtn setTitle:propertyModel.propertyName forState:UIControlStateNormal];
    [_textBtn setTitle:propertyModel.propertyName forState:UIControlStateSelected];
    
    _textBtn.selected = propertyModel.isSelected;
    
    if (propertyModel.isSelected) {
        self.textBtn.backgroundColor = [UIColor redColor];
    }else{
        self.textBtn.backgroundColor = [UIColor groupTableViewBackgroundColor];
    }
    
}

@end
