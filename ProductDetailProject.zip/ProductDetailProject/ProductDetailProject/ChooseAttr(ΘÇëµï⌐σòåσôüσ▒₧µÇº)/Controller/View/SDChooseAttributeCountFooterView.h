






#import <UIKit/UIKit.h>
#import "PPNumberButton.h"

@interface SDChooseAttributeCountFooterView : UICollectionReusableView

/**     */
@property (strong, nonatomic) PPNumberButton *numberButton;
/**        */
@property (nonatomic, copy) void (^changeNumCellBlock)(CGFloat number);
/**     */
@property (nonatomic, assign) NSInteger maxValue;
@end
