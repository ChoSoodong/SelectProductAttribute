






#import "SDChooseAttributeCountFooterView.h"
#import "Masonry.h"

@interface SDChooseAttributeCountFooterView()

/** 数量标题  */
@property(nonatomic, retain) UILabel *countLabel;

@end

@implementation SDChooseAttributeCountFooterView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self) {
        self = [super initWithFrame:frame];
        self.userInteractionEnabled = YES;
        [self setupViewCell];
    }
    return self;
}

- (void)setupViewCell {
    
    _countLabel = [UILabel new];
    _countLabel.text = @"数量";
    _countLabel.textColor = [UIColor blackColor];
    _countLabel.font = [UIFont systemFontOfSize:14];
    [self addSubview:_countLabel];
    
    _numberButton = [PPNumberButton new];
    // 开启抖动动画
    _numberButton.shakeAnimation = YES;
    //设置边框颜色
    _numberButton.borderColor = [UIColor blackColor];
    // 设置最小值
    _numberButton.minValue = 1;
    // 设置最大值
    _numberButton.maxValue = 10;
    //输入框中的内容
    _numberButton.currentNumber = 0;
    // 设置输入框中的字体大小
    _numberButton.inputFieldFont = 14;
    _numberButton.increaseTitle = @"＋";
    _numberButton.decreaseTitle = @"－";
    __weak typeof(self) _weakSelf = self;
    _numberButton.resultBlock = ^(PPNumberButton *ppBtn, CGFloat number, BOOL increaseStatus) {
        _weakSelf.changeNumCellBlock ? _weakSelf.changeNumCellBlock(number) : nil;
    };
    [self addSubview:_numberButton];
    
    [_countLabel mas_makeConstraints:^(MASConstraintMaker *make){
        make.left.equalTo(self).offset(15);
        make.centerY.equalTo(self.numberButton);
    }];
    
    [_numberButton mas_makeConstraints:^(MASConstraintMaker *make){
        make.right.equalTo(self.mas_right).offset(-15);
        make.bottom.equalTo(self.mas_bottom).offset(0);
        make.width.offset(150);
        make.height.offset(35);
    }];
}

- (void)setMaxValue:(NSInteger)maxValue {
    _maxValue = maxValue;
    _numberButton.maxValue = maxValue;
}

@end
