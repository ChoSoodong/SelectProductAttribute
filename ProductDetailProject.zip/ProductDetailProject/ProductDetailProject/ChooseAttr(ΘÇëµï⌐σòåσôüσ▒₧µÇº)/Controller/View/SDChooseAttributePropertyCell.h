






#import <UIKit/UIKit.h>
@class SDPropertyModel;

@interface SDChooseAttributePropertyCell : UICollectionViewCell

/**  属性名   */
@property (copy, nonatomic) SDPropertyModel *propertyModel;

/** 选中点击回调 */
@property (nonatomic, copy) void(^CellButtonBlock)(SDPropertyModel *propertyModel);

@end
