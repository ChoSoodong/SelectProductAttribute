






#import <UIKit/UIKit.h>

@interface SDChooseAttributePropertyFooter : UICollectionReusableView
/**     */
@property (strong, nonatomic) UIView *line;
@end
