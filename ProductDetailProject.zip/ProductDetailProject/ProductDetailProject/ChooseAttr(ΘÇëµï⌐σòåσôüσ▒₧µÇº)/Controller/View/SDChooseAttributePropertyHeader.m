






#import "SDChooseAttributePropertyHeader.h"

@implementation SDChooseAttributePropertyHeader

- (instancetype)initWithFrame:(CGRect)frame {
    if (self) {
        self = [super initWithFrame:frame];
        self.backgroundColor = [UIColor whiteColor];
        
        _headernameL = [UILabel new];
        _headernameL.textColor = [UIColor blackColor];
        _headernameL.font = [UIFont systemFontOfSize:14];
        _headernameL.numberOfLines = 0;
        _headernameL.text = @"属性名字";
        [self addSubview:_headernameL];
    }
    return self;
}

-(void)layoutSubviews{
    [super layoutSubviews];
    
    _headernameL.frame = CGRectMake(10, 0, self.bounds.size.width-20, self.bounds.size.height);
}


@end
