






#import "SDChooseAttributePropertyFooter.h"

@implementation SDChooseAttributePropertyFooter

- (instancetype)initWithFrame:(CGRect)frame {
    if (self) {
        self = [super initWithFrame:frame];
        self.backgroundColor = [UIColor whiteColor];
        
        _line = [UIView new];
        _line.backgroundColor = [UIColor lightTextColor];
        [self addSubview:_line];
    }
    return self;
}

-(void)layoutSubviews{
    [super layoutSubviews];
    
    _line.frame = CGRectMake(0, self.bounds.size.height - 1, self.bounds.size.width, 1);
}
@end
