






#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SDPropertyModel : NSObject

/** 属性名字 */
@property (nonatomic, copy) NSString *propertyName;
/** 是否选中 */
@property (nonatomic, assign) BOOL isSelected;

@end

NS_ASSUME_NONNULL_END
