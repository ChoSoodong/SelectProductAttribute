






#import <Foundation/Foundation.h>
#import "SDPropertyModel.h"

NS_ASSUME_NONNULL_BEGIN


@interface SDChooseAttributeModel : NSObject

/** 商品图片url */
@property (nonatomic, copy) NSString *productImgUrl;
/** 商品价格 */
@property (nonatomic, copy) NSString *productPrice;
/** 库存 */
@property (nonatomic, copy) NSString *productStock;
/** 颜色规格属性数组 */
@property (nonatomic, strong) NSArray<SDPropertyModel *> *colorsArray;
/** 尺码属性数组 */
@property (nonatomic, strong) NSArray<SDPropertyModel *> *sizeArray;

@end






NS_ASSUME_NONNULL_END
