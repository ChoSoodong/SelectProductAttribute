



/***************** 选择商品属性 *****************/


#import <UIKit/UIKit.h>


@interface SDChooseGoodsAttributeController : UIViewController

/** 是否从购物车弹出  */
@property (nonatomic, assign) BOOL isFromBuyCart;
/** 是否从立即购买弹出  */
@property (nonatomic, assign) BOOL fromBuyNowBtn;

@property (nonatomic,strong)UIViewController *fatherVC;

@end
