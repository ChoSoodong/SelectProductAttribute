






#import "SDChooseGoodsAttributeController.h"
#import "Masonry.h"
#import "02 Macro.h"

#import "EasyTextView.h"

#import "UIImageView+WebCache.h"
#import "NSString+HXExtension.h"



#import "SDChooseAttributePropertyCell.h"
#import "SDChooseAttributePropertyHeader.h"
#import "SDChooseAttributePropertyFooter.h"
#import "SDChooseAttributeCountFooterView.h"

#import "SDChooseAttributeModel.h"


#define KPadding 10

@interface SDChooseGoodsAttributeController()<UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>

//商品图片
@property (strong, nonatomic)  UIImageView *goodImageView;
//价格
@property (strong, nonatomic)  UILabel *lb_price;
//库存
@property (strong, nonatomic)  UILabel *lb_stock;
//请选择属性
@property (strong, nonatomic)  UILabel *detailLabel;
/** 关闭 */
@property (strong, nonatomic)  UIButton *closeBtn;
/**     */
@property (strong, nonatomic) UIView *line;
/**     */
@property (strong, nonatomic) UICollectionView *collectionView;
/** 确定 当从购物车进入时,才显示 */
@property (nonatomic, strong) UIButton *sureBtn;
/** 加入购物车 */
@property (strong, nonatomic)  UIButton *addCartBtn;
/** 立即购买 */
@property (strong, nonatomic)  UIButton *buyGoodsBtn;
/**  商品属性模型   */
@property (strong, nonatomic) SDChooseAttributeModel *productModel;

////////////////// 记录选中的属性 //////////////////////
/** 已选商品颜色属性  */
@property (nonatomic, copy) NSString *selectColor;
/** 选择商品的数量  */
@property (nonatomic, copy) NSString *selectNum;
/** 选择商品的尺码  */
@property (nonatomic, copy) NSString *selectSize;
/////////////////////////////////////////////////////

/**  所选属性最大数量   */
@property (nonatomic, assign) NSInteger maxQuantity;

@end

@implementation SDChooseGoodsAttributeController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _selectSize = @"";
    _selectColor = @"";
    _selectNum = @"1";
    
    [self loadData];
    
    [self setupSubViews];
}
#pragma mark - 网络请求
-(void)loadData{
    
    _productModel = [[SDChooseAttributeModel alloc] init];
    _productModel.productImgUrl = @"http://b-ssl.duitang.com/uploads/item/201612/07/20161207133847_s3dCK.thumb.700_0.jpeg";
    _productModel.productPrice = @"99";
    _productModel.productStock = @"10";
    NSMutableArray *arrM = [[NSMutableArray alloc] init];
    for (NSInteger i = 0; i < 10; i++) {
        SDPropertyModel *model = [[SDPropertyModel alloc] init];
        model.propertyName = [NSString stringWithFormat:@"暗夜绿色 %zd",i];
        model.isSelected = NO;
        [arrM addObject:model];
    }
    _productModel.colorsArray = arrM.copy;
    
    NSMutableArray *arrayM = [[NSMutableArray alloc] init];
    for (NSInteger i = 0; i < 2; i++) {
        SDPropertyModel *model = [[SDPropertyModel alloc] init];
        model.propertyName = [NSString stringWithFormat:@"200Cm * 300cm %zd",i];
        model.isSelected = NO;
        [arrayM addObject:model];
    }
     _productModel.sizeArray = arrayM.copy;
}


- (void)setupSubViews {
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    _goodImageView = [[UIImageView alloc] init];
    _goodImageView.backgroundColor = [UIColor groupTableViewBackgroundColor];
    _goodImageView.contentMode = UIViewContentModeScaleAspectFill;
    _goodImageView.layer.cornerRadius = 5;
    _goodImageView.layer.masksToBounds = YES;
    [self.view addSubview:_goodImageView];
    
    _lb_price = [UILabel new];
    _lb_price.textColor = [UIColor redColor];
    _lb_price.font = [UIFont systemFontOfSize:14];
    _lb_price.numberOfLines = 0;
    _lb_price.text = @"￥14.50";
    [self.view addSubview:_lb_price];
    
    _lb_stock = [UILabel new];
    _lb_stock.textColor = [UIColor darkGrayColor];
    _lb_stock.font = [UIFont systemFontOfSize:14];
    _lb_stock.numberOfLines = 0;
    _lb_stock.text = @"库存100000件";
    [self.view addSubview:_lb_stock];
    
    _detailLabel = [UILabel new];
    _detailLabel.textColor = [UIColor darkGrayColor];
    _detailLabel.font = [UIFont systemFontOfSize:14];
    _detailLabel.numberOfLines = 0;
    _detailLabel.text = @"请选择 属性";
    [self.view addSubview:_detailLabel];
    
    _closeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [_closeBtn setBackgroundImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
    [_closeBtn addTarget:self action:@selector(dismissViewBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_closeBtn];
    
    _line = [UIView new];
    _line.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:_line];
    
    UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
    _collectionView.backgroundColor = [UIColor whiteColor];
    _collectionView.showsVerticalScrollIndicator = NO;
    _collectionView.delegate = self;
    _collectionView.dataSource = self;
    [_collectionView registerClass:[SDChooseAttributePropertyCell class] forCellWithReuseIdentifier:NSStringFromClass([SDChooseAttributePropertyCell class])];
    [_collectionView registerClass:[SDChooseAttributePropertyHeader class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:NSStringFromClass([SDChooseAttributePropertyHeader class])];
    [_collectionView registerClass:[SDChooseAttributePropertyFooter class] forSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:NSStringFromClass([SDChooseAttributePropertyFooter class])];
    [_collectionView registerClass:[SDChooseAttributeCountFooterView class] forSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:NSStringFromClass([SDChooseAttributeCountFooterView class])];
    [_collectionView reloadData];
    [_collectionView setContentInset:UIEdgeInsetsMake(0, 0, 44, 0)];
    [self.view addSubview:_collectionView];
    [_collectionView selectItemAtIndexPath:[NSIndexPath indexPathForRow:0  inSection:0] animated:YES scrollPosition:UICollectionViewScrollPositionNone];
    
    _addCartBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [_addCartBtn setTitle:@"加入购物车" forState:UIControlStateNormal];
    [_addCartBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_addCartBtn setBackgroundColor:[UIColor orangeColor]];
    _addCartBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    [_addCartBtn addTarget:self action:@selector(addCartBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_addCartBtn];
    
    _buyGoodsBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [_buyGoodsBtn setTitle:@"立即购买" forState:UIControlStateNormal];
    [_buyGoodsBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_buyGoodsBtn setBackgroundColor:[UIColor redColor]];
    _buyGoodsBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    [_buyGoodsBtn addTarget:self action:@selector(buyNowBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_buyGoodsBtn];
    
    _sureBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [_sureBtn setTitle:@"确定" forState:UIControlStateNormal];
    [_sureBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_sureBtn setBackgroundColor:[UIColor redColor]];
    _sureBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    [self.view addSubview:_sureBtn];

    if (_isFromBuyCart) {// 购物车页面进入，不可修改数量
        _sureBtn.hidden = NO;

    } else {// 商品详情页面进入，可以修改数量
        _sureBtn.hidden = YES;
    }

    __weak typeof(self) _weakSelf = self;
    [_goodImageView sd_setImageWithURL:[NSURL URLWithString:self.productModel.productImgUrl] placeholderImage:nil completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        if (image && cacheType == SDImageCacheTypeNone) {
            _weakSelf.goodImageView.alpha = 0;
            [UIView animateWithDuration:1.0 animations:^{
                _weakSelf.goodImageView.alpha = 1.0f;
            }];
        } else {
            _weakSelf.goodImageView.alpha = 1.0f;
        }
    }];

    _maxQuantity = [self.productModel.productStock integerValue];
    _lb_stock.text = [NSString stringWithFormat:@"库存%@件", self.productModel.productStock];
    
    _lb_price.text = [NSString stringWithFormat:@"￥%@", self.productModel.productPrice];
    
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    
    [_goodImageView mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(self.view.mas_top).offset(-KPadding * 2);
        make.left.equalTo(self.view).offset(KPadding);
        make.width.height.offset(100);
    }];
    
    [_lb_price mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(self.view.mas_top).offset(KPadding);
        make.left.equalTo(self.goodImageView.mas_right).offset(KPadding);
    }];
    
    [_lb_stock mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(self.lb_price.mas_bottom).offset(5);
        make.left.equalTo(self.lb_price).offset(0);
    }];
    
    [_detailLabel mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(self.lb_stock.mas_bottom).offset(5);
        make.left.equalTo(self.lb_price).offset(0);
        make.right.offset(-KPadding);
    }];
    
    [_closeBtn mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(self.view.mas_top).offset(KPadding);
        make.right.equalTo(self.view.mas_right).offset(-KPadding);
        make.width.height.offset(25);
    }];

    [_line mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(self.goodImageView.mas_bottom).offset(15);
        make.left.equalTo(self.view).offset(KPadding);
        make.right.equalTo(self.view.mas_right).offset(-KPadding);
        make.height.offset(1);
    }];
    
    [_collectionView mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(self.line.mas_bottom).offset(0);
        make.left.right.equalTo(self.view).offset(0);
        make.bottom.equalTo(self.addCartBtn.mas_top).offset(0);
    }];

    [_addCartBtn mas_makeConstraints:^(MASConstraintMaker *make){
        make.left.equalTo(self.view).offset(0);
        make.right.equalTo(self.buyGoodsBtn.mas_left).offset(0);
        make.bottom.equalTo(self.view.mas_bottom).offset(-kTabbarSafeBottomMargin);
        make.height.offset(44);
    }];
    if (_fromBuyNowBtn) {
        [_buyGoodsBtn mas_makeConstraints:^(MASConstraintMaker *make){
            make.right.equalTo(self.view.mas_right).offset(0);
            make.bottom.equalTo(self.addCartBtn.mas_bottom).offset(0);
            make.height.offset(44);
            make.width.offset(SCREEN_WIDTH);
        }];
    } else {
        [_buyGoodsBtn mas_makeConstraints:^(MASConstraintMaker *make){
            make.right.equalTo(self.view.mas_right).offset(0);
            make.bottom.equalTo(self.addCartBtn.mas_bottom).offset(0);
            make.height.offset(44);
            make.width.offset(SCREEN_WIDTH / 2);
        }];
    }
    
    
    [_sureBtn mas_makeConstraints:^(MASConstraintMaker *make){
        make.left.right.equalTo(self.view).offset(0);
        make.bottom.equalTo(self.view).offset(-kTabbarSafeBottomMargin);
        make.height.offset(44);
    }];
}

#pragma mark -- UICollectionViewDelegate, UICollectionViewDataSource
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 2;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    if (section == 0) {
        return self.productModel.colorsArray.count;
    }else{
        return self.productModel.sizeArray.count;
    }
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    SDChooseAttributePropertyCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([SDChooseAttributePropertyCell class]) forIndexPath:indexPath];
    
    if (indexPath.section == 0) {
        cell.propertyModel = self.productModel.colorsArray[indexPath.row];
    }else{
        cell.propertyModel = self.productModel.sizeArray[indexPath.row];
    }
    
    __weak typeof(self) weakSelf = self;
    //颜色
    if (indexPath.section == 0) {
        //点击回调
        cell.CellButtonBlock = ^(SDPropertyModel *propertyModel) {
            
            weakSelf.selectColor = propertyModel.isSelected ? propertyModel.propertyName : @"";

            for (SDPropertyModel *model in self.productModel.colorsArray) {
                if (![model.propertyName isEqualToString:propertyModel.propertyName]) {

                        model.isSelected = NO;
                }
            }
            [self finishChooseAttribute];
            [weakSelf.collectionView reloadData];
        };
    }
    
    //尺码
    if (indexPath.section == 1) {
        //点击回调
        cell.CellButtonBlock = ^(SDPropertyModel *propertyModel) {
            
            weakSelf.selectSize = propertyModel.isSelected ? propertyModel.propertyName : @"";
            
            for (SDPropertyModel *model in self.productModel.sizeArray) {
                if (![model.propertyName isEqualToString:propertyModel.propertyName]) {
                        model.isSelected = NO;
                }
            }
            [self finishChooseAttribute];
            [weakSelf.collectionView reloadData];
        };
    }
    
   
    return cell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {
    __weak typeof(self) _weakSelf = self;
    if ([kind isEqualToString:UICollectionElementKindSectionHeader]) {
        SDChooseAttributePropertyHeader *view = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:NSStringFromClass([SDChooseAttributePropertyHeader class]) forIndexPath:indexPath];
        view.headernameL.text = indexPath.section == 0 ? @"颜色" : @"尺码";
        return view;
    } else {
        if (indexPath.section == 1) {
            SDChooseAttributeCountFooterView *countView = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:NSStringFromClass([SDChooseAttributeCountFooterView class]) forIndexPath:indexPath];
            countView.maxValue = _maxQuantity;
            countView.changeNumCellBlock = ^(CGFloat number) {//选择商品数量
                _weakSelf.selectNum = [NSString stringWithFormat:@"%.0f", number];
            };
            return countView;
        }
        SDChooseAttributePropertyFooter *line = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:NSStringFromClass([SDChooseAttributePropertyFooter class]) forIndexPath:indexPath];
        return line;
    }
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    
}

#pragma mark - UICollectionViewDelegateFlowLayout
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.section == 0) {
       
        SDPropertyModel *model = self.productModel.colorsArray[indexPath.row];
        NSString *text = model.propertyName;
        CGFloat width = [NSString calculateRowWidth:text withHeight:20 font:12];
        
        return CGSizeMake(width + Padding * 4, 25);
    }else{
        SDPropertyModel *model = self.productModel.sizeArray[indexPath.row];
        NSString *text = model.propertyName;
        CGFloat width = [NSString calculateRowWidth:text withHeight:20 font:12];
        
        return CGSizeMake(width + Padding * 4, 25);
    }
    
    
}
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    return UIEdgeInsetsMake(0, Padding, 0, Padding);
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section {
    return CGSizeMake(SCREEN_WIDTH, 44);
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForFooterInSection:(NSInteger)section {
    if (section == 1) {
        return CGSizeMake(SCREEN_WIDTH, 60);
    }
    return CGSizeMake(SCREEN_WIDTH - Padding * 2, 11);
}


/**
 完成选择属性
 */
- (void)finishChooseAttribute {
    
    if ([_selectColor isEqualToString:@""] && [_selectSize isEqualToString:@""]) {
        _detailLabel.text = @"请选择 属性";
    }else{
        NSString *tempStr = [NSString stringWithFormat:@"%@:%@  %@:%@", @"颜色", _selectColor,@"尺码",_selectSize];
        _detailLabel.text = tempStr;
    }

    
}

/**
 立即购买
 */
- (void)buyNowBtnClick {
    

    [self finishChooseAttribute];
    
    if ([_selectColor isEqual:@""]) {// 未选择商品属性，给予提示
        [EasyTextView showInfoText:@"请选择 颜色"];
        return;
    }else if ([_selectSize isEqual:@""]) {// 未选择商品属性，给予提示
        [EasyTextView showInfoText:@"请选择 尺寸"];
        return;
    }else{
        
        NSLog(@"%@", [NSString stringWithFormat:@"立即购买:[%@]--[%@]--[%@]",_selectColor,_selectSize,_selectNum]);
        
    }
    
    
}

/**
 加入购物车
 */
- (void)addCartBtnClick {
    
    [self finishChooseAttribute];
    
    if ([_selectColor isEqual:@""]) {// 未选择商品属性，给予提示
        [EasyTextView showInfoText:@"请选择 颜色"];
        return;
    }else if ([_selectSize isEqual:@""]) {// 未选择商品属性，给予提示
        [EasyTextView showInfoText:@"请选择 尺寸"];
        return;
    }else{
        
        NSLog(@"%@", [NSString stringWithFormat:@"加入购物车:[%@]--[%@]--[%@]",_selectColor,_selectSize,_selectNum]);
        
    }
}



- (void)dismissViewBtnClick {
    [self dismissViewControllerAnimated:YES completion:nil];
}


@end
