






#import "ProductListViewController.h"
#import "SDChooseGoodsAttributeController.h"
#import "XPSemiModalConfiguration.h"
#import "02 Macro.h"
#import "UIViewController+XPSemiModal.h"

static NSString *const TCGoodsCellID = @"TCGoodsCell";

@interface ProductListViewController ()
/** 显示 */
@property (nonatomic, strong) UIButton *showBtn;

@end

@implementation ProductListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _showBtn = [[UIButton alloc] initWithFrame:CGRectMake(100, 200, 100, 60)];
    [_showBtn setTitle:@"显   示" forState:UIControlStateNormal];
    _showBtn.titleLabel.font = [UIFont systemFontOfSize:20];
    [_showBtn addTarget:self action:@selector(showButtonClick) forControlEvents:UIControlEventTouchUpInside];
    [_showBtn setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
    [_showBtn setTitleColor:[UIColor orangeColor] forState:UIControlStateHighlighted];
    [self.view addSubview:_showBtn];
    
    
}

-(void)showButtonClick{
 
    
    SDChooseGoodsAttributeController *chooseGoodsAttributeVC = [SDChooseGoodsAttributeController new];
    chooseGoodsAttributeVC.isFromBuyCart = NO;
    chooseGoodsAttributeVC.fromBuyNowBtn = NO;
    chooseGoodsAttributeVC.fatherVC = self;
    XPSemiModalConfiguration *config = [XPSemiModalConfiguration defaultConfiguration];
    [self presentSemiModalViewController:chooseGoodsAttributeVC contentHeight:SCREEN_HEIGHT - 200 configuration:config completion:nil];
    
}


@end
